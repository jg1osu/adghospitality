window.ADG_CONFIG = {"email":"alisa@adghospitality.com","bookingUrl":"","consultationMinutes":30,"inquiryEnabled":false,"inquiryEndpoint":"/inquiry.php"};
